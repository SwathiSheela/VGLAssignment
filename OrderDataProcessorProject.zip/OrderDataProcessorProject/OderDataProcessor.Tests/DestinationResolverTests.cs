﻿using OrderDataProcessor.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace OrderDataProcessor.Tests
{
    public class DestinationResolverTests
    {
        private DestinationResolverService _destinationResolver;

        public DestinationResolverTests()
        {
            _destinationResolver = new DestinationResolverService();
        }

        [Fact]
        public void ResolveDestination_ShouldReturnMelbourne_WhenSupplierIsSFC01()
        {
            var supplierCode = "SFC01";
            var destination = _destinationResolver.MapDestination(supplierCode, "");
            Assert.Equal("Melbourne AUMEL", destination);
        }

        [Fact]
        public void ResolveDestination_ShouldReturnSydney_WhenSupplierIsYIP1()
        {
            var supplierCode = "YIP-1";
            var destination = _destinationResolver.MapDestination(supplierCode, "");
            Assert.Equal("Sydney AUSYD", destination);
        }

        [Fact]
        public void ResolveDestination_ShouldReturnNull_WhenSupplierIsUnknown()
        {
            var supplier = "UNKNOWN SUPPLIER";
            var destination = _destinationResolver.MapDestination(supplier, "UNKNOWN SUPPLIER");
            Assert.NotNull(destination);
        }
    }
}
