﻿using OrderDataProcessor.Models;
using OrderDataProcessor.Services;

public class Program
{
    public static void Main(string[] args)
    {
        try
        {
            string inputFilePath = @"C:\Users\User\OneDrive\Documents\SwathiAssignment\Data.csv";
            if (!File.Exists(inputFilePath))
            {
                Console.WriteLine("Input file not found.");
                return;
            }

            FileParserService fileParser = new FileParserService();
            (List<HeaderRecord> headers, List<DetailRecord> details) headers1 = fileParser.ParseCsvFile(inputFilePath);

            XmlGeneratorService xmlGenerator = new XmlGeneratorService();
            string xmlOutput = xmlGenerator.GenerateXmlFromRawData(headers1.headers, headers1.details);

            string outputFilePath = @"C:\Users\User\OneDrive\Documents\SwathiAssignment\Output.xml"; // Update with desired output file path
            File.WriteAllText(outputFilePath, xmlOutput);

            Console.WriteLine("XML file generated successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Something went wrong while parsing the data", ex.Message);

        }
    }
}
